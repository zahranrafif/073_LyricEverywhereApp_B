package com.example.lyriceverywhere;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.ArrayList;

public class DatabaseHandler extends SQLiteOpenHelper {

    private final static int DATABASE_VERSION = 3;
    private final static String DATABASE_NAME = "db_music";
    private final static String TABLE_LAGU = "t_lagu";
    private final static String KEY_ID_LAGU = "ID_Lagu";
    private final static String KEY_JUDUL = "Judul";
    private final static String KEY_ARTIST = "Artist";
    private final static String KEY_GAMBAR = "Gambar";
    private final static String KEY_ALBUM = "Album";
    private final static String KEY_LIRIK_LAGU = "Lirik_Lagu";
    private final static String KEY_LINK = "Link";
    private Context context;

    public DatabaseHandler(Context ctx) {
        super(ctx, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = ctx;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_LAGU = "CREATE TABLE " + TABLE_LAGU
                + "(" + KEY_ID_LAGU + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + KEY_JUDUL + " TEXT, " + KEY_ARTIST + " TEXT, "
                + KEY_GAMBAR + " TEXT, " + KEY_ALBUM + " TEXT, "
                + KEY_LIRIK_LAGU + " TEXT, " + KEY_LINK + " TEXT);";

        db.execSQL(CREATE_TABLE_LAGU);
        inisialisasiLaguAwal(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_LAGU;
        db.execSQL(DROP_TABLE);
        onCreate(db);
    }

    public void tambahLagu(Lagu dataLagu) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataLagu.getJudul());
        cv.put(KEY_ARTIST, dataLagu.getArtist());
        cv.put(KEY_GAMBAR, dataLagu.getGambar());
        cv.put(KEY_ALBUM, dataLagu.getAlbum());
        cv.put(KEY_LIRIK_LAGU, dataLagu.getLirikLagu());
        cv.put(KEY_LINK, dataLagu.getLink());

        db.insert(TABLE_LAGU, null, cv);
        db.close();
    }

    public void tambahLagu(Lagu dataLagu, SQLiteDatabase db) {
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataLagu.getJudul());
        cv.put(KEY_ARTIST, dataLagu.getArtist());
        cv.put(KEY_GAMBAR, dataLagu.getGambar());
        cv.put(KEY_ALBUM, dataLagu.getAlbum());
        cv.put(KEY_LIRIK_LAGU, dataLagu.getLirikLagu());
        cv.put(KEY_LINK, dataLagu.getLink());

        db.insert(TABLE_LAGU, null, cv);
    }

    public void editLagu(Lagu dataLagu) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(KEY_JUDUL, dataLagu.getJudul());
        cv.put(KEY_ARTIST, dataLagu.getArtist());
        cv.put(KEY_GAMBAR, dataLagu.getGambar());
        cv.put(KEY_ALBUM, dataLagu.getAlbum());
        cv.put(KEY_LIRIK_LAGU, dataLagu.getLirikLagu());
        cv.put(KEY_LINK, dataLagu.getLink());

        db.update(TABLE_LAGU, cv, KEY_ID_LAGU + "=?", new String[]{String.valueOf(dataLagu.getIdLagu())});

        db.close();
    }

    public void hapusLagu(int idLagu) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_LAGU, KEY_ID_LAGU + "=?", new String[]{String.valueOf(idLagu)});
        db.close();
    }

    public ArrayList<Lagu> getAllLagu() {
        ArrayList<Lagu> dataLagu = new ArrayList<>();
        String query = "SELECT * FROM " + TABLE_LAGU;
        SQLiteDatabase db = getReadableDatabase();
        Cursor csr = db.rawQuery(query, null);
        if (csr.moveToFirst()) {
            do {
                Lagu tempLagu = new Lagu(
                        csr.getInt(0),
                        csr.getString(1),
                        csr.getString(2),
                        csr.getString(3),
                        csr.getString(4),
                        csr.getString(5),
                        csr.getString(6)
                );

                dataLagu.add(tempLagu);
            } while (csr.moveToNext());
        }
        return dataLagu;
    }

    private String storeImageFile(int id) {
        String location;
        Bitmap image = BitmapFactory.decodeResource(context.getResources(), id);
        location = InputActivity.saveImageToInternalStorage(image, context);
        return location;
    }

    private void inisialisasiLaguAwal(SQLiteDatabase db) {
        int idLagu = 0;

        //Data Lagu ke 1
        Lagu lagu1 = new Lagu(
                idLagu,
                "Tujuh Belas",
                "Tulus",
                storeImageFile(R.drawable.manusia),
                "Manusia",
                "Masihkah kau mengingat di saat kita masih 17?\n" +
                        "Waktu di mana tanggal-tanggal merah terasa sungguh meriah\n" +
                        "Masihkah kauingat cobaan terberat kita, Matematika?\n" +
                        "Masihkah engkau ingat lagu di radio yang merdu mengudara?\n" +
                        "Kita masih sebebas itu\n" +
                        "Rasa takut yang tak pernah mengganggu\n" +
                        "Batas naluri bahaya\n" +
                        "Dulu tingginya lebihi logika\n" +
                        "Putaran Bumi dan waktu yang terus berjalan menempa kita\n" +
                        "Walau kini kita terpisah, namun, jiwaku tetap di sana (hey)\n" +
                        "oh, di masa\n" +
                        "Rasa takut yang tak pernah mengganggu\n" +
                        "Di masa naluri bahaya\n" +
                        "Dulu tingginya lebihi logika\n" +
                        "Muda jiwa, selamanya muda\n" +
                        "Kisah kita abadi selamanya\n" +
                        "kita masih sebebas itu\n" +
                        "(Rasa takut yang tak pernah mengganggu)\n" +
                        "Rasa takut yang tak pernah mengganggu\n" +
                        "(Batas naluri bahaya, oh-oh)\n" +
                        "(Dulu tingginya lebihi logika)\n" +
                        "Sederas apa pun arus di hidupmu\n" +
                        "Genggam terus kenangan tentang kita\n" +
                        "Seberapa pun dewasa mengujimu\n" +
                        "Takkan lebih dari yang engkau bisa\n" +
                        "Dan kisah kita abadi untuk s'lama-lamanya\n",

                "https://g.co/kgs/Aio1YD"
        );

        tambahLagu(lagu1, db);
        idLagu++;

        // Data Lagu ke 2
        Lagu lagu2 = new Lagu(
                idLagu,
                "Rantau",
                "Feby Putri",
                storeImageFile(R.drawable.riuh),
                "Riuh",
                "Beranjak 'tuk melihat apa kabarnya dunia\n" +
                        "Memulai lembaran baru\n" +
                        "Amat jauh berbedanya\n" +
                        "Dari nyaman yang s'lalu kubanggakan\n" +
                        "Berjejak di kota yang ramai jua s'lama ini\n" +
                        "Beberapa t'lah kupahami\n" +
                        "Masih ada turut serta\n" +
                        "Kesemogaan dari yang berarti\n" +
                        "Bernyanyilah\n" +
                        "Seirama\n" +
                        "Sya-la-la-la-la-la-la-la-la\n" +
                        "Sya-la-la-la-la-la-la-la-la\n" +
                        "Berpadu, banyak jiwa yang awal tak saling tahu\n" +
                        "Memulai cerita baru\n" +
                        "Kerap kali hilang risau\n" +
                        "Dalam lingkup yang menurutku utuh\n" +
                        "He-eh\n" +
                        "Hu-uh-uh\n" +
                        "Hu-uh-hu-hu\n" +
                        "Hu-uh-uh\n" +
                        "Bernyanyilah\n" +
                        "Seirama\n" +
                        "Sya-la-la-la-la-la-la-la-la\n" +
                        "Sya-la-la-la-la-la-la-la-la\n" +
                        "Bernyanyilah\n" +
                        "Menarilah\n" +
                        "Sya-la-la-la-la-la-la-la-la\n" +
                        "Sya-la-la-la-la-la-la-la-la\n" +
                        "Bernyanyilah\n" +
                        "Menarilah\n",

                "https://g.co/kgs/mmYtZ3"
        );

        tambahLagu(lagu2, db);
        idLagu++;

        // Data Lagu ke 3
        Lagu lagu3 = new Lagu(
                idLagu,
                "Ghost",
                "Justin Bieber",
                storeImageFile(R.drawable.ghost),
                "Justice",
                "Youngblood thinks there's always tomorrow\n" +
                        "I miss your touch on nights when I'm hollow\n" +
                        "I know you crossed a bridge that I can't follow\n" +
                        "Since the love that you left is all that I get\n" +
                        "I want you to know\n" +
                        "That if I can't be close to you\n" +
                        "I'll settle for the ghost of you\n" +
                        "I miss you more than life (more than life)\n" +
                        "And if you can't be next to me\n" +
                        "Your memory is ecstasy\n" +
                        "I miss you more than life\n" +
                        "I miss you more than life\n" +
                        "Youngblood thinks there's always tomorrow (woo)\n" +
                        "I need more time but time can't be borrowed\n" +
                        "I'd leave it all behind if I could follow\n" +
                        "Since the love that you left is all that I get\n" +
                        "I want you to know\n" +
                        "That if I can't be close to you\n" +
                        "I'll settle for the ghost of you\n" +
                        "I miss you more than life (more than life), yeah\n" +
                        "And if you can't be next to me\n" +
                        "Your memory is ecstasy (oh)\n" +
                        "I miss you more than life\n" +
                        "I miss you more than life\n" +
                        "Whoa\n" +
                        "Na, na-na\n" +
                        "More than life\n" +
                        "Oh\n" +
                        "So if I can't get close to you\n" +
                        "I'll settle for the ghost of you\n" +
                        "But I miss you more than life\n" +
                        "And if you can't be next to me\n" +
                        "Your memory is ecstasy\n" +
                        "I miss you more than life\n" +
                        "I miss you more than life\n",

                "https://g.co/kgs/i6CtYu"
        );

        tambahLagu(lagu3, db);
        idLagu++;

        // Data Lagu ke 4
        Lagu lagu4 = new Lagu(
                idLagu,
                "Evaluasi",
                "Hindia",
                storeImageFile(R.drawable.evaluasi),
                "Evaluasi",
                "Yang tak bisa terobati\n" +
                        "Biarlah\n" +
                        "Mengering sendiri\n" +
                        "Menghias tubuh dan\n" +
                        "Yang mengevaluasi\n" +
                        "Ragamu\n" +
                        "Hanya kau sendiri\n" +
                        "Mereka tak mampu\n" +
                        "Melewati yang telah kau lewati\n" +
                        "Tiap berganti hari\n" +
                        "Rintangan yang kau hadapi\n" +
                        "Masalah yang mengeruh\n" +
                        "Ho, perasaan yang rapuh\n" +
                        "Ini belum separuhnya\n" +
                        "Biasa saja\n" +
                        "Kamu tak apa\n" +
                        "Yang selalu ingin ambil peran\n" +
                        "Hanya berlomba menjadi lebih\n" +
                        "Sedih dari dirimu\n" +
                        "Muak dikesampingkan\n" +
                        "Disamakan\n" +
                        "Hatimu terluka, sempurna\n" +
                        "Masalah yang mengeruh\n" +
                        "Ho, perasaan yang rapuh\n" +
                        "Ini belum separuhnya\n" +
                        "Biasa saja\n" +
                        "Kamu tak apa\n" +
                        "Perjalanan yang jauh\n" +
                        "Kau bangun untuk bertaruh\n" +
                        "Hari belum selesai\n" +
                        "Biasa saja\n" +
                        "Kamu tak apa\n" +
                        "Bilas muka, gosok gigi, evaluasi\n" +
                        "Tidur sejenak menemui esok pagi\n" +
                        "Walau pedihku bersamamu kali ini\n" +
                        "Ku masih ingin melihatmu esok hari\n" +
                        "Bilas muka, gosok gigi, evaluasi\n" +
                        "Tidur sejenak menemui esok pagi\n" +
                        "Walau pedihku bersamamu kali ini\n" +
                        "Ku masih ingin melihatmu esok hari\n" +
                        "Bilas muka, gosok gigi, evaluasi\n" +
                        "Tidur sejenak menemui esok pagi\n" +
                        "Walau pedihku bersamamu kali ini\n" +
                        "Ku masih ingin melihatmu esok hari",
                "https://www.google.com/search?q=evaluasi+hindia+lyrics&oq=evaluasi+hindia+lyrics&aqs=chrome.0.69i59j0.1783j0j9&sourceid=chrome&ie=UTF-8"
        );

        tambahLagu(lagu4, db);
        idLagu++;

        // Data Lagu ke 5
        Lagu lagu5 = new Lagu(
                idLagu,
                "A Man Without Love",
                "Engelbert Humperdinck",
                storeImageFile(R.drawable.aman),
                "A Man Without Love",
                "… I can remember when we walked together\n" +
                        "Sharing a love I thought would last forever\n" +
                        "Moonlight to show the way so we can follow\n" +
                        "Waiting inside her eyes was my tomorrow\n" +
                        "Then somethin' changed her mind, her kisses told me\n" +
                        "I had no lovin' arms to hold me\n" +
                        "… Every day I wake up, then I start to break up\n" +
                        "Lonely is a man without love\n" +
                        "Every day I start out, then I cry my heart out\n" +
                        "Lonely is a man without love\n" +
                        "… Every day I wake up, then I start to break up\n" +
                        "Knowing that it's cloudy above\n" +
                        "Every day I start out, then I cry my heart out\n" +
                        "Lonely is a man without love\n" +
                        "… I cannot face this world that's fallen down on me\n" +
                        "So, if you see my girl please send her home to me\n" +
                        "Tell her about my heart that's slowly dying\n" +
                        "Say I can't stop myself from crying\n" +
                        "… Every day I wake up, then I start to break up\n" +
                        "Lonely is a man without love\n" +
                        "Every day I start out, then I cry my heart out\n" +
                        "Lonely is a man without love\n" +
                        "… Every day I wake up, then I start to break up\n" +
                        "Knowing that it's cloudy above\n" +
                        "Every day I start out, then I cry my heart out\n" +
                        "Lonely is a man without love\n" +
                        "… Every day I wake up, then I start to break up\n" +
                        "Lonely is a man without love\n" +
                        "Every day I start out, then I cry my heart out\n" +
                        "Lonely is a man without love\n" ,

                "https://g.co/kgs/EZ8srg"
        );

        tambahLagu(lagu5, db);
    }
}
